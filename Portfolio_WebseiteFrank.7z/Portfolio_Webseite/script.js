function openTab(evt, tabName) {
    // Hide all tab content
    const tabcontents = document.getElementsByClassName("tabcontent");
    for (let i = 0; i < tabcontents.length; i++) {
        tabcontents[i].style.display = "none";
    }

    // Remove "active" class from all buttons
    const tablinks = document.getElementsByClassName("tablink");
    for (let i = 0; i < tablinks.length; i++) {
        tablinks[i].className = tablinks[i].className.replace(" active", "");
    }

    // Show the current tab and add an "active" class to the button
    document.getElementById(tabName).style.display = "block";
    evt.currentTarget.className += " active";
}

function toggleVisibility1() {
    const textField = document.getElementById('readonlyFieldCode1');
    if (textField.style.display === 'none' || textField.style.display === '') {
        textField.style.display = 'block'; // Show the text field
    } else {
        textField.style.display = 'none'; // Hide the text field
    }
}
function toggleVisibility2() {
    const textField = document.getElementById('readonlyFieldCode2');
    if (textField.style.display === 'none' || textField.style.display === '') {
        textField.style.display = 'block'; // Show the text field
    } else {
        textField.style.display = 'none'; // Hide the text field
    }
}